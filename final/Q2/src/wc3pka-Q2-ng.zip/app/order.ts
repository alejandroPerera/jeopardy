export class Order {
   constructor(
      public mon1: number | null,
      public mon2: number | null,
      public tue1: number | null,
      public tue2: number | null,
      public wed1: number | null,
      public wed2: number | null,
      public thu1: number | null,
      public thu2: number | null,
      public fri1: number | null,
      public fri2: number | null,
  ){}
}  